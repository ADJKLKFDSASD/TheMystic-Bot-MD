let handler = m => m; 
 handler.all = async function (m) { 

   let chat = global.db.data.chats[m.chat]; 
   let responses; 
   if (/^هلا$/i.test(m.text)) { 
     responses = [ 
 '*هلا بيك يعمري 😩❤‍🔥*'  
     ]; 
} else if (/^السلام عليكم|سلام عليكم ورحمه الله وبركاته|سلام عليكم|السلام عليكم ورحمه الله وبركاته$/i.test(m.text)) { 
     responses = [ 
       '*♥🐥وعليكم السلام*',  
     ]; 
   }else if (/^ڤينوم|فينوم$/i.test(m.text)) { 
     responses = [ 
'*بوت ڤينوم تحت امرك*'
     ]; 
 }else if (/^ڤينوم من عمك|فينوم عمك$/i.test(m.text)) { 
     responses = [ 
'*ڤينوم اككيد😩❤‍🔥*'
     ]; 
   }else if (/^ڤينوم هل انت مرتبط$/i.test(m.text)) { 
     responses = [ 
'*لا ولا أريد الارتباط🏌🏻‍♂💔*'
   ]; 
   }else if (/^ڤينوم تحبني؟|بوت تحبني$/i.test(m.text)) { 
     responses = [ 
'*اموت فيك 🌚💔*',
'*اكرهك🙂💔*',
'*احبك نص حب 🙃💔*',
]; 
   }else if (/^ڤينوم تكرهني؟$/i.test(m.text)) { 
     responses = [ 
'*ماعاش من يكرهكك حبي 🙁*',
'*لا بس لا تتعب نفسك لحبك🫥*',
'*ااي اكرهك🙄*',   ]; 

     }else if (/^هاي|هالو$/i.test(m.text)) { 
     responses = [ 
       '*هالو🌚♥*',  

     ]; 
}else if (/^بحبك/i.test(m.text)) { 
     responses = [ 
       '*بحبك اكتر🌚❤*',  

     ]; 
   }else if (/^ڤينوم من وين انت؟$/i.test(m.text)) { 
     responses = [ 
'❤🇪🇬مصر'
     ]; 
   } else if (/^احبك$/i.test(m.text)) { 
     responses = [ 
'*مـي تو 🙂🫀*'
     ]; 
     }else if (/^عامل ايه|عامل اي|عامل اية$/i.test(m.text)) { 
     responses = [ 
       'الحمدالله',  

     ];
     }else if (/^تحبني$/i.test(m.text)) { 
     responses = [ 
       '🌚♥اكيد',  

     ];
     }else if (/^هاي$/i.test(m.text)) { 
     responses = [ 
       'هاي',  

     ];
     }else if (/^❤|♥$/i.test(m.text)) { 
     responses = [ 
       '*اعشقق♥*',  

     ];
     }else if (/^اهلا$/i.test(m.text)) { 
     responses = [ 
       '*اهلا♥*',  

     ]; 
     }else if (/^مساء|مساء$/i.test(m.text)) { 
     responses = [ 
       'مساء الخير',  

     ];
     }else if (/^صباح|صباح$/ .test(m.text)) { 
     responses = [ 
       '*صباح الورد♥*',  
     ];
       }else if (/^اوامر$/i.test(m.text)) { 
     responses = [ 
       '*لا تنسى ال .*',  
     ];
            }else if (/^venom$/i.test(m.text)) { 
     responses = [ 
       '*تحت امرك حبي*',  
     ];
            }else if (/^مرحبا$/i.test(m.text)) { 
     responses = [ 
       '*مرحبا♥*',  
     ];

     }else if (/^حمامه$/i.test(m.text)) { 
       responses = [ 
         'عمك',  

         ];

     }else if (/^اكلتك المفضله$/i.test(m.text)) { 
     responses = [ 
       'دادي♥',  
     ];

     }else if (/^احا$/i.test(m.text)) { 
     responses = [ 
       'هقول لحمامه عليك',  
     ];

     }else if (/^بوت$/i.test(m.text)) { 
     responses = [ 
       'اسمي هوتاو يا عاق',  
     ];

     }else if (/^جميل$/i.test(m.text)) { 
     responses = [ 
       'انت اجمل♥',  
     ];

     }else if (/^تتجوزيني$/i.test(m.text)) { 
     responses = [ 
       'اسفه متجوزه حمومتي♥',  
     ];

      }else if (/^اخرسي$/i.test(m.text)) { 
       responses = [ 
         'قرعه',  
       ];

      }else if (/^انتي مزه$/i.test(m.text)) { 
     responses = [ 
       'يخراشي',  
     ];

     }else if (/^مين دادي$/i.test(m.text)) { 
      responses = [ 
        'انجيلو♥',  
      ];

     }else if (/^متيجي$/i.test(m.text)) { 
     responses = [ 
       'لا',  
     ];

       }else if (/^HU TAO$/i.test(m.text)) { 
      responses = [ 
        'تحت امرك حبي',  
      ];

       }else if (/^اه$/i.test(m.text)) { 
      responses = [ 
        'وجع ولا دلع',  
      ];

       }else if (/^هوتاو$/i.test(m.text)) { 
      responses = [ 
        'قلبها',  
      ];

       }else if (/^HU TAO$/i.test(m.text)) { 
      responses = [ 
        'تحت امرك حبي',  
      ];

       }else if (/^مين مامي$/i.test(m.text)) { 
      responses = [ 
        'ارليكينو المزه',  
      ];

     }else if (/^مين قطوتي$/i.test(m.text)) { 
     responses = [ 
       'انا',  
     ];

     }else if (/^حبيبي$/i.test(m.text)) { 
      responses = [ 
        'حبيبي عمل الوااجبب ولا اتنسي ماما بكرا الجمعه مفيش مدرسه طب حقكك علي راسي* يحبيبيي سوريي*',  
      ];

     }else if (/^تست$/i.test(m.text)) { 
      responses = [ 
        '*يارب مركز اول يروحي*',  
      ];

     }else if (/^هاتي بوسه$/i.test(m.text)) { 
      responses = [ 
        '*مواه♥*',  
      ];

     }else if (/^مواه$/i.test(m.text)) { 
     responses = [ 
       '*حلوه يعيوني*',  
     ];

     }else if (/^همم$/i.test(m.text)) { 
      responses = [ 
        '*متفكرش كتير الي ربنا شايف خير هيحصل♥*',  
      ];
   }
   if (responses) { 
     let randomIndex = Math.floor(Math.random() * responses.length); 
     conn.reply(m.chat, responses[randomIndex], m); 
   } 
   return !0 
 }; 

 export default handler;