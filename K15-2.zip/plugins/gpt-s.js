function _0x4904() {
    const _0x5a06d2 = [
        '\x63\x68\x61\x74',
        '\x6b\x65\x79',
        '\x6c\x6c\x61\x6d\x61',
        '\x32\x34\x35\x35\x31\x36\x35\x71\x59\x69\x66\x41\x78',
        '\x2a\u0627\u0643\u0640\u062a\u0640\u0628\x20\u0646\u0640\u0635\x20\u0644\u0627\u0633\u0640\u062a\u0640\u0637\u0640\u064a\u0640\u0639\x20\u0627\u0644\u0640\u0631\u062f\x20\u0639\u0640\u0644\u0640\u064a\u0640\u0647\x0a\u00b0\u00b0\u00b0\u00b0\u00b0\u00b0\u00b0\u00b0\u00b0\u00b0\u00b0\u00b0\u00b0\u00b0\u00b0\u00b0\x0a',
        '\x31\x31\x38\x37\x37\x30\x39\x30\x49\x57\x6c\x4c\x76\x49',
        '\x32\x30\x39\x37\x50\x52\x4a\x6e\x71\x4d',
        '\x31\x32\x62\x48\x6e\x6d\x62\x41',
        '\x73\x65\x6e\x64\x4d\x65\x73\x73\x61\x67\x65',
        '\x76\x76\x76\x6f\x6f\x6e\x6e',
        '\x68\x65\x6c\x70',
        '\x71\x75\x6f\x74\x65\x64',
        '\x73\x65\x6e\x64\x50\x72\x65\x73\x65\x6e\x63\x65\x55\x70\x64\x61\x74\x65',
        '\x72\x65\x70\x6c\x79',
        '\x33\x36\x32\x62\x67\x42\x63\x54\x4f',
        '\x64\x61\x74\x61',
        '\x45\x72\x72\x6f\x72\x3a',
        '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x75\x72\x75\x67\x70\x74\x2e\x63\x79\x63\x6c\x69\x63\x2e\x61\x70\x70\x2f\x63\x68\x61\x74\x3f\x70\x72\x6f\x6d\x70\x74\x3d',
        '\x34\x33\x38\x63\x46\x67\x70\x51\x4e',
        '\x76\x65\x65\x65\x65\x65',
        '\x32\x30\x35\x36\x31\x37\x68\x42\x66\x78\x56\x5a',
        '\x6a\x73\x6f\x6e',
        '\x32\x32\x37\x35\x37\x69\x51\x6a\x4d\x69\x57',
        '\u0633\u064a\u0631\u064a',
        '\x38\x34\x44\x50\x4d\x64\x6b\x4f',
        '\x33\x34\x32\x59\x79\x62\x65\x48\x49',
        '\x74\x65\x78\x74',
        '\x34\x34\x30\x32\x34\x72\x52\x79\x67\x71\x70',
        '\x32\x39\x37\x34\x33\x37\x30\x31\x50\x4f\x76\x67\x46\x79',
        '\x31\x31\x4a\x48\x59\x6e\x47\x6e',
        '\x65\x72\x72\x6f\x72'
    ];
    _0x4904 = function () {
        return _0x5a06d2;
    };
    return _0x4904();
}
(function (_0x1b997d, _0x1b9375) {
    const _0x3f060b = _0x1b997d();
    while (!![]) {
        try {
            const _0x4a51a0 = parseInt(_0x5dc8(0x1dd)) / 0x1 * (parseInt(_0x5dc8(0x1c9)) / 0x2) + parseInt(_0x5dc8(0x1e3)) / 0x3 * (-parseInt(_0x5dc8(0x1c8)) / 0x4) + -parseInt(_0x5dc8(0x1d2)) / 0x5 + parseInt(_0x5dc8(0x1e1)) / 0x6 * (parseInt(_0x5dc8(0x1c6)) / 0x7) + -parseInt(_0x5dc8(0x1cb)) / 0x8 * (-parseInt(_0x5dc8(0x1d5)) / 0x9) + parseInt(_0x5dc8(0x1d4)) / 0xa * (-parseInt(_0x5dc8(0x1cd)) / 0xb) + -parseInt(_0x5dc8(0x1d6)) / 0xc * (-parseInt(_0x5dc8(0x1cc)) / 0xd);
            if (_0x4a51a0 === _0x1b9375) {
                break;
            } else {
                _0x3f060b['push'](_0x3f060b['shift']());
            }
        } catch (_0x27bed8) {
            _0x3f060b['push'](_0x3f060b['shift']());
        }
    }
}(_0x4904, 0xb76ec));
import _0x1a72b8 from '\x6e\x6f\x64\x65\x2d\x66\x65\x74\x63\x68';
let handler = async (_0x2385bd, {
    text: _0x1e6610,
    usedPrefix: _0x5cf304,
    command: _0x339cbe
}) => {
    if (!_0x1e6610 && !(_0x2385bd['\x71\x75\x6f\x74\x65\x64'] && _0x2385bd[_0x5dc8(0x1da)]['\x74\x65\x78\x74'])) {
        throw _0x5dc8(0x1d3) + global[_0x5dc8(0x1e2)];
    }
    if (!_0x1e6610 && _0x2385bd[_0x5dc8(0x1da)] && _0x2385bd[_0x5dc8(0x1da)][_0x5dc8(0x1ca)]) {
        _0x1e6610 = _0x2385bd[_0x5dc8(0x1da)][_0x5dc8(0x1ca)];
    }
    try {
        conn[_0x5dc8(0x1db)]('\x63\x6f\x6d\x70\x6f\x73\x69\x6e\x67', _0x2385bd[_0x5dc8(0x1cf)]);
        const _0x57b351 = encodeURIComponent(_0x1e6610);
        const _0x2e3ce4 = _0x5dc8(0x1d1);
        const _0x252675 = _0x5dc8(0x1e0) + _0x57b351 + '\x26\x6d\x6f\x64\x65\x6c\x3d' + _0x2e3ce4;
        const _0x1649f0 = await _0x1a72b8(_0x252675);
        const _0x1b647f = await _0x1649f0[_0x5dc8(0x1c5)]();
        const _0x40cfd8 = _0x1b647f[_0x5dc8(0x1de)];
        await conn[_0x5dc8(0x1d7)](_0x2385bd['\x63\x68\x61\x74'], {
            '\x72\x65\x61\x63\x74': {
                '\x74\x65\x78\x74': '\ud83e\udd16',
                '\x6b\x65\x79': _0x2385bd[_0x5dc8(0x1d0)]
            }
        });
        _0x2385bd[_0x5dc8(0x1dc)](_0x40cfd8);
    } catch (_0x105b38) {
        console[_0x5dc8(0x1ce)](_0x5dc8(0x1df), _0x105b38);
        throw '\x2a\x45\x52\x52\x4f\x52\x2a';
    }
};
handler[_0x5dc8(0x1d9)] = [_0x5dc8(0x1d8)];
handler['\x63\x6f\x6d\x6d\x61\x6e\x64'] = [_0x5dc8(0x1c7)];
function _0x5dc8(_0x5b5304, _0x5d02ca) {
    const _0x4904f4 = _0x4904();
    _0x5dc8 = function (_0x5dc871, _0x38e5f5) {
        _0x5dc871 = _0x5dc871 - 0x1c5;
        let _0x397d18 = _0x4904f4[_0x5dc871];
        return _0x397d18;
    };
    return _0x5dc8(_0x5b5304, _0x5d02ca);
}
export default handler;